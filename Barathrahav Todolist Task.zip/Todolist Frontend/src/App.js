import React from "react";
import Todo from "./components/Todolist/Todolist";
import "bootstrap/dist/css/bootstrap.css";

function App() {
  return (
    <div className="App">
      <Todo />
    </div>
  );
}

export default App;
